<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\SmsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/notify', [HomeController::class, 'dbnotify']);

Route::get('/display/{id}', [HomeController::class, 'display']);


Route::get('/sms', function () {
    return view('sms');
});

Route::post('/sms',[SmsController::class, 'twiliosms']);

Route::post('/call',[SmsController::class, 'twiliocall']);