<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\NotificationData;
use App\Notifications\UserFollowNotification;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;




class HomeController extends Controller
{


    public function dbnotify()
    {
        $user = User::where('id',2)->first();

    //    dd($user);

    Notification::send($user, new UserFollowNotification($user));  //best way that to notify user

            // $user->notify(new UserFollowNotification($user));  //2nd way to notify user

            dd('Notification Send');
    }


    public function display($id)
    {
        $notify= NotificationData::where('notifiable_id',$id)->get();

    //   $rows= compact($notify);

        // dd($notify);

        // return view('Note')->with($rows);
        return view('Note',['notify'=>$notify]);

    }

   
}
