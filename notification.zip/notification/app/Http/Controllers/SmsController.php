<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Twilio\Rest\Client;
header("content-type: text/xml");

class SmsController extends Controller
{
    public function twiliosms(Request $request)
    {
     $account_sid =  env('TWILIO_SID');
     $account_token =  env('TWILIO_TOKEN');
     $number =  env('TWILIO_FROM');

     $client = new Client($account_sid,$account_token);
     $client->messages->create('+91'.$request->number, [
        'from'=>$number,
        'body'=>$request->message,
     ]);

     return "Message Sent......";
    }


    public function twiliocall(Request $request)
    {
        $account_sid =  env('TWILIO_SID');
        $account_token =  env('TWILIO_TOKEN');
        $number =  env('TWILIO_FROM');
   
        $client = new Client($account_sid,$account_token);
        $client->calls->create('+91'.$request->number, $number, [
           'method'=>"GET",
            'url'=> "http://demo.twilio.com/docs/voice.xml",
            "twiml" => "<Response><Say>Hello My Name is Sampark</Say></Response>"
        ]);



    }
}
