$(document).ready(function () {

    // $('.delbtn').on('click', function (e) {   //both way we  call even
        $(document).on('click', '.delbtn', function(e) {    //this is best way to call event
        e.preventDefault();
        var id = $(this).data("id");

//    console.log(id);
        $.ajax({
            url: "http://127.0.0.1:8000/deleterow/"+id,
            type: "get",
            success: function(result) {
                console.log(result);
                location.reload(true);

                // $('#msg').removeClass('d-none');   //msg show
                // $('#msg #msgshow').html(result.success);

            },
            error: function (error) {
                console.log(error)

                // $('#msgdiv').removeClass('d-none');

                // $('#msg').html(result.error);


            }


        })

    });


    // $('#closebtn').on('click', function() {   //msg show
    //     $(this).parent().addClass('d-none');
    // })
});
