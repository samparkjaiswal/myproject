



<table class="table table-responsive table-striped">

  <thead class="table-dark" style="text-align: center">
      <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th colspan="2">Operation</th>

      </tr>
  </thead>


  <tbody style="text-align: center">
    @foreach($records as $record)
      <tr>
        <td>{{ $record->id }}</td>
        <td>{{ $record->name }}</td>
        <td>{{ $record->email }}</td>
        <td><button class="btn btn-warning editbtn" data-id="{{ $record->id }}">Edit</button></td>
        <td><button class="btn btn-danger delbtn"  data-id="{{ $record->id }}">Delete</button></td>
      </tr>
      @endforeach
  </tbody>




</table>

{{-- <script src="{{ asset('crudjs/delete.js') }}"></script> --}}

{{-- <script src="{{ asset('crudjs/edit.js') }}"></script> --}}


{{-- <script>
  $('.delbtn').on('click', function(e) {
    e.preventDefault();
    var id = $(this).data("id");
    console.log(id);
  })
</script> --}}


