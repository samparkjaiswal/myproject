<!doctype html>
<html lang="en">
  <head>
    <title>Ajax Data Header</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"> </script>

    

  </head>
  <body>

    <div class="container">


      <div class="row">

        <div class="col-md-12">

          

          


        <?php if(Session::has('successfull')): ?>

                <div class="alert alert-success" id="msg" role="alert">   <!-- custome create by me -->

                 <span id="msgshow"><?php echo e(Session::get('successfull')); ?></span>
                     <button type="button" class="close" id="closebtn"  aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>

                </div>

        <?php endif; ?>

       </div>

      </div>

        <div class="row">



            <div class="col-md-12" id="fetchdata">




            </div>

        </div>

    </div>


    <script src="<?php echo e(asset('crudjs/show.js')); ?>"></script>



  </body>

</html>
<?php /**PATH /opt/lampp/htdocs/ajaxcrudb/resources/views/showfirst.blade.php ENDPATH**/ ?>