

    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <form action="" class="editpage" method="POST" autocomplete="off" id="updatefrm" >

                    <input type="hidden" name="_token" id="csrf" value="<?php echo e(csrf_token()); ?>">

                    


                    <div class="form-group">
                      <label for="">Name</label>
                      <input type="text" name=""  class="form-control" id="Name" placeholder="" value="<?php echo e($editdata->name); ?>" aria-describedby="helpId">
                        <span></span>
                    </div>

                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="text" name="" class="form-control" id="Email" placeholder="" value="<?php echo e($editdata->email); ?>" aria-describedby="helpId">
                          <span></span>
                      </div>

                      <button class="btn btn-success updatebtn" data-id=<?php echo e($editdata->id); ?>>Update Data</button>

                </form>
            </div>
        </div>
    </div>

    
<?php /**PATH /opt/lampp/htdocs/ajaxcrudb/resources/views/editview.blade.php ENDPATH**/ ?>