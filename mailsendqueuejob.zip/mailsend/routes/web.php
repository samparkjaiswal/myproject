<?php

use App\Mail\SendTestMail;
use App\Jobs\SendTestMailJob;
use App\Mail\SendMarkdownMail;
use Nexmo\Laravel\Facade\Nexmo;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SmsController;
use App\Http\Controllers\MailController;
use Illuminate\Support\Facades\Notification;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//if we send mail without view then change in .env file write below code
//if we want to sent mail using laravel mail then use that way
// Route::get('/', function () {
//     $data = ['name'=> "Sampark Jaiswal"];
//     Mail::send([], [], function($msg){
//         $msg->to("test@test.com", "Advance Laravel User")
//             ->subject("Advance Larvel Series")
//             ->setBody("Hi, This is working fine");
        
//     });

//     echo "Mail Sent";
// });

//if we send mail on view then use the below code
//in this we have edit the code on view like css,html,js etc design for massages designing

// Route::get('/', function () {
//         $data = ['name'=> "Sampark Jaiswal"];
//         Mail::send('email', $data, function($msg){
//             $msg->to("test@test.com", "Advance Laravel User")
//                 ->subject("Advance Larvel Series");
               
            
//         });
    
//         echo "Mail Sent";
//     });



//if we want to mailable class then we run a cmd php artisan make:mail classname
//-> this cmd make mail name folder in app and there we write the code for send msg and view name
//the below route call that class 
//in this we have edit the code on view like css,html,js etc design for massages designing
//if we want to sent mail using laravel mail then use that way

// Route::get('/', function(){

//     Mail::to("test1@test.com", "New User TEst")->send(new SendTestMail);
//     echo "Mail Send";
// });

////if we want to sent mail using laravel mail then use that way
//if we want to make mailable class with markdown(it's provide builtin templete and it make a view via artisan cmd) 
//if we use markdown functionality then it's provide buit in templete and show our massages in that templete
//in this we have write the massage are atribute in mail class and echo then on view. it show this in templete
//it's use for forget password,track order,click here
//it's provide a button with use we perform action
//php artisan make:mail SendMarkdownMail --markdown=emails.markdown(if we want place blade file in folder then use (.) operator)
// php artisan make:mail SendMarkdownMai --markdown=emails_markdow(if we want place blade file in views folder then use(_) operator)
//both is used in middle of folder and filename
//php artisan make:mail WelcomeMail -m folder.filename(if we want to filename then we use (_) underscore with filename)  //-m is use for markable
//php artisan help make:mail(for see shortcut)
//note: here we only use send method and we use (to() method) then we call it mailable class build function/below function













//2nd Way ->

// If you want to send the information via just one channel, say email only, then use Mailable. If you are likely to send the information as email or SMS, some other medium or multiple(eg. email and SMS), your best bet is to use Notification.


// Yes, definitively, if each email layout is different, you should use Mailable

// Mailable is the new way to send emails, easier than before. More customizable than Notifications.

// Notification is very nice if you want to send a predefined layout in differents channel ( Mail, SMS, Slack, etc )

//if we want to send mail and sms notification using laravel notification then use this way and routes

// Route::get('/sms',[SmsController::class,'index']); 


//send sms using nexmo/vonage package 


// Route::get('/', function() {
//     Nexmo::message()->send([

//         'to' => '+918765894438',
//         'from' => '+916392254020',
//         'text' => 'Hello robin.'

//     ]); SendTestMailJob::dispatch()->delay(now()->addSeconds(5));
// });


// Route::get('/notify',[SmsController::class, 'index']);



// Route::get('/', function (){    //use only Queue Direct Not any Job uses

//     dispatch(function (){
//         Mail::to("test1@test.com")               //clouser function
//             ->send(new SendMarkdownMail());
//     })->delay(now()->addSeconds(5));
//     echo "Mail Sent";
// });


// Route::get('/', function(){    //1st way for Queue With Jobs

//     dispatch(new SendTestMailJob())->delay(now()->addSeconds(5));
// });

// Route::get('/', function(){    //2nd way for Queue With Jobs  without Contoller

//    SendTestMailJob::dispatch()->delay(now()->addSeconds(5));
// });

Route::get('/notify/{id}',[MailController::class, 'mailjobqueue']);  //using controlle Job and Queue 