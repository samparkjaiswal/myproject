<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use Nexmo\Laravel\Facade\Nexmo;
use App\Models\User;
use App\Notifications\OrderShipped;

class SmsController extends Controller
{
    // public function index()
    // {
    //     Nexmo::message()->send([   //it's use for send sms

    //                 'to' => '+918765894438',
    //                 'from' => '+916392254020',
    //                 'text' => 'Hello Sampark! please visit home at Diwali.'
            
    //             ]);

    //             echo "sms send";
    // }



    public function index()   //using this way we send the mail and massage both
    {

        $user =User::first();

        $enrollment = [
            'body' => 'hello this is mail notification',   //for mail send
            'enrollmetText' => 'your ticket has been cnf',
            'url' => url('/'),
            'thankyou' => 'you have 14 days to enroll'
        ];

        Notification::send($user, new OrderShipped($enrollment));

        // Nexmo::message()->send([      //for sms send
        //             'to' => '+918765894438',
        //             'from' => '+916392254020',
        //             'text' => 'Hello Sampark! please visit chandigarh.'
            
        //         ]);

                echo "sms send";
    }
}
