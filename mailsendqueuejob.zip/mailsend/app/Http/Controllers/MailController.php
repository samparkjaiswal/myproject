<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Jobs\SendTestMailJob;

class MailController extends Controller
{
   public function mailjobqueue($id)
   {

  $user=  User::where('id',$id)->first();
    SendTestMailJob::dispatch($user)->delay(now()->addSeconds(10));
    echo "massage send";
   }
}
