<!doctype html>
<html lang="en">
  <head>
	<title>Update</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

  <div class="container">
        <div class="row">
					
				<div class="col-md-12">



        <form action="<?php echo base_url('updatedata/'.$data->id) ?>" method="post">

           
                <div class="form-group">
                  <label for="">Name</label>
                  <input type="text" name="name" id="" class="form-control" value="<?php echo $data->name ?>" placeholder="" aria-describedby="helpId">
                </div>
           
         
                <div class="form-group">
                  <label for="">Email</label>
                  <input type="email" name="email" id="" value="<?php echo $data->email ?>" class="form-control" placeholder="" aria-describedby="helpId">
                </div>
            
    
			<!-- 
            <button type="submit" name="btn">Submit</button> -->

            <input type="submit" name="update" class="btn btn-success" value="Update">

            </form>

				</div>
        </div>
    </div>
	  

  </body>
</html>
